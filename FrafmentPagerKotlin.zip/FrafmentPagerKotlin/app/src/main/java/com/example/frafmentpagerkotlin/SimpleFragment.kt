package com.example.frafmentpagerkotlin

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

import androidx.fragment.app.Fragment




class SimpleFragment: Fragment() {
    // Our companion object which
    // we call to make a new Fragment
    companion object {
        // Holds the fragment id passed in when created
        val messageID = "messageID"

        fun newInstance(message: String)
                : SimpleFragment {
            // Create the fragment
            val fragment = SimpleFragment()

            // Create a bundle for our message/id
            val bundle = Bundle(1)
            // Load up the Bundle
            bundle.putString(messageID, message)
            fragment.arguments = bundle
            return fragment
        }
    }

    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?)
            : View? {

        // Get the id from the Bundle
        val message = arguments!!.getString(messageID)

        // Inflate the view as normal
        val view = inflater.inflate(
                R.layout.fragment_layout,
                container,
                false)

        // Get a reference to textView
        val messageTextView = view.findViewById<View>(R.id.txtCountry) as TextView
        val flag = view.findViewById<View>(R.id.imgFlag) as ImageView
        val btnToast = view.findViewById<View>(R.id.btnInfo) as Button

        // Display the id in the TextView
        messageTextView.text = message
        when(message) {
            "Canada" -> flag.setImageResource(R.drawable.canada)
            "Russia" -> flag.setImageResource(R.drawable.russia)
            "Japan" -> flag.setImageResource(R.drawable.japan)
            "Poland" -> flag.setImageResource(R.drawable.poland)
            else -> {
                flag.setImageResource(R.drawable.canada)
            }
        }






        when(message) {
            "Canada" ->  btnToast.setOnClickListener{Toast.makeText(getActivity(), "Info about Canada", Toast.LENGTH_LONG).show()}
            "Russia" ->  btnToast.setOnClickListener{Toast.makeText(getActivity(), "Info about Russia", Toast.LENGTH_LONG).show()}
            "Japan" ->  btnToast.setOnClickListener{Toast.makeText(getActivity(), "Info about Japan", Toast.LENGTH_LONG).show()}
            "Poland" ->  btnToast.setOnClickListener{Toast.makeText(getActivity(), "Info about Poland", Toast.LENGTH_LONG).show()}
            else -> {
                btnToast.setOnClickListener{Toast.makeText(getActivity(), "Info about Canada", Toast.LENGTH_LONG).show()}
            }
        }


        // We could also handle any UI
        // of any complexity in the usual way
        //
        // ..
        // ..

        return view
    }
}